from fastapi import APIRouter, Depends, HTTPException, status
from app.core.ai_agent import generate_insight_for_link
from app.middleware.auth import get_current_user
from app.models.user import User
import uuid

from pydantic import BaseModel

class InsightRequest(BaseModel):
    user_prompt: str | None = None

router = APIRouter(prefix="/ai", tags=["AI Analyst"])

@router.post("/insights/link/{link_id}")
async def get_link_insight(
    link_id: uuid.UUID,
    request: InsightRequest,
    current_user: User = Depends(get_current_user),
):
    """
    Generates a natural language insight report for a specific link using the AI Agent.
    """
    insight_text = await generate_insight_for_link(str(link_id), str(current_user.id), request.user_prompt)
    
    if "Unauthorized" in insight_text:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You do not own this link.")
    
    if "Link not found" in insight_text:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Link not found.")
        
    return {"insight": insight_text}
