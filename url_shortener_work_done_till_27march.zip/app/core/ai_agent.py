import json
import datetime
from uuid import UUID
from typing import Annotated, Any
from typing_extensions import TypedDict
from langchain_core.messages import AnyMessage, SystemMessage, HumanMessage
from langchain_core.runnables import RunnableConfig
from langchain_groq import ChatGroq
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from langchain_core.tools import tool

from app.core.database import AsyncSessionLocal
from app.crud.link import get_link_analytics, get_link_by_id, get_links_for_project
from app.crud.project import get_project_by_id
from app.core.config import settings

# LangSmith natively reads from os.environ, not our Pydantic settings.
if hasattr(settings, "LANGCHAIN_API_KEY") and settings.LANGCHAIN_API_KEY:
    import os
    os.environ["LANGCHAIN_TRACING_V2"] = "true" if settings.LANGCHAIN_TRACING_V2 else "false"
    os.environ["LANGCHAIN_ENDPOINT"] = settings.LANGCHAIN_ENDPOINT
    os.environ["LANGCHAIN_API_KEY"] = settings.LANGCHAIN_API_KEY
    os.environ["LANGCHAIN_PROJECT"] = settings.LANGCHAIN_PROJECT

class AgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    # Configurable parameters will hold the user_id


async def _get_link_analytics_impl(link_id: str, user_id: str) -> str:
    try:
        if not user_id:
            return json.dumps({"error": "Unauthorized: No user context provided."})
            
        link_uuid = UUID(link_id)
        user_uuid = UUID(user_id)
        
        async with AsyncSessionLocal() as db:
            link = await get_link_by_id(db, link_uuid)
            if not link:
                return json.dumps({"error": "Link not found."})
                
            if str(link.created_by) != str(user_uuid):
                return json.dumps({"error": "Unauthorized: You do not own this link."})
                
            data = await get_link_analytics(db, link_uuid)
            
            # Convert UUIDs and datetime objects to strings for JSON serialization
            serialized_data = json.loads(json.dumps(data, default=str))
            return json.dumps(serialized_data)
            
    except ValueError:
        return json.dumps({"error": "Invalid UUID format."})
    except Exception as e:
        return json.dumps({"error": str(e)})


@tool
async def get_link_analytics_tool(link_id: str, config: RunnableConfig) -> str:
    """
    Fetches detailed click analytics and demographics for a specific link.
    Returns JSON string with total clicks, unique visitors, devices, browsers, OS, referers, and timeline.
    """
    user_id = config.get("configurable", {}).get("user_id")
    return await _get_link_analytics_impl(link_id, user_id)


async def _get_project_summary_impl(project_id: str, user_id: str) -> str:
    try:
        if not user_id:
            return json.dumps({"error": "Unauthorized: No user context provided."})
            
        proj_uuid = UUID(project_id)
        user_uuid = UUID(user_id)
        
        async with AsyncSessionLocal() as db:
            project = await get_project_by_id(db, proj_uuid)
            if not project:
                return json.dumps({"error": "Project not found."})
                
            if str(project.owner_id) != str(user_uuid):
                return json.dumps({"error": "Unauthorized: You do not own this project."})
                
            links, total = await get_links_for_project(db, proj_uuid, page=1, per_page=100)
            
            # Serialize link objects
            serialized_links = []
            for item in links:
                link_obj = item["link"]
                serialized_links.append({
                    "id": str(link_obj.id),
                    "short_code": link_obj.short_code,
                    "original_url": link_obj.original_url,
                    "title": link_obj.title,
                    "click_count": item["click_count"]
                })
                
            return json.dumps({"project_name": project.name, "total_links": total, "links": serialized_links})
            
    except ValueError:
        return json.dumps({"error": "Invalid UUID format."})
    except Exception as e:
        return json.dumps({"error": str(e)})

@tool
async def get_project_summary_tool(project_id: str, config: RunnableConfig) -> str:
    """
    Retrieves a list of all links with their total click counts within a specific project.
    Returns JSON string with project details and list of links.
    """
    user_id = config.get("configurable", {}).get("user_id")
    return await _get_project_summary_impl(project_id, user_id)


# Define tools
tools = [get_link_analytics_tool, get_project_summary_tool]

# Base LLM
api_key = settings.model_dump().get("GROQ_API_KEY", "")
llm = ChatGroq(model_name="llama-3.1-8b-instant", groq_api_key=api_key) if api_key else None
llm_with_tools = llm.bind_tools(tools) if llm else None

# Node for LLM
async def agent_node(state: AgentState):
    if not llm_with_tools:
        # Fallback if no API key is provided
        return {"messages": [HumanMessage(content="AI Analyst is not configured (missing GROQ_API_KEY).")]}
    
    messages = state["messages"]
    response = await llm_with_tools.ainvoke(messages)
    return {"messages": [response]}

# Build Graph
workflow = StateGraph(AgentState)
workflow.add_node("agent", agent_node)
workflow.add_node("tools", ToolNode(tools))

workflow.add_edge(START, "agent")
workflow.add_conditional_edges("agent", tools_condition)
workflow.add_edge("tools", "agent")

ai_agent = workflow.compile()

async def generate_insight_for_link(link_id: str, user_id: str, user_prompt: str = None) -> str:
    """Convenience function to generate a one-off insight for a specific link."""
    if not llm:
        return "AI Analyst is not configured. Please add GROQ_API_KEY to environment variables."
        
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
    system_prompt = SystemMessage(content="""
    You are an expert Data Analyst and Growth Marketer. 
    You analyze traffic data and provide actionable, concise insights based on user needs.
    Keep your response to 2 short paragraphs max. Focus on peak hours, device anomalies, or strong referers.
    You are an expert Data and Traffic Analyst.
    You analyze link traffic data and provide actionable, concise, and easy-to-understand insights.
    Your analysis should be tailored to the general user, whether they are a developer, a content creator, or just sharing a link with friends.
    Keep your response to 2 short paragraphs max unless the user asks for more detail. Focus on peak activity times, geographic or device anomalies, or strong referring sources.
    Do not mention UUIDs in your response.
    
    Current System Time: {current_time}
    Use this time to understand relative temporal references (e.g. 'yesterday', 'last week').
    """)
    
    if user_prompt and user_prompt.strip():
        human_content = f"The user is asking a specific question about link ID {link_id}: '{user_prompt.strip()}'. Please use your tools to fetch the necessary analytics and answer their exact question."
    else:
        human_content = f"Please fetch the analytics for link ID {link_id} and provide a summary of its performance over time."
        
    human_prompt = HumanMessage(content=human_content)
    
    config = {"configurable": {"user_id": user_id}}
    
    result = await ai_agent.ainvoke(
        {"messages": [system_prompt, human_prompt]},
        config=config
    )
    
    # The last message is the AI's final response
    return result["messages"][-1].content
