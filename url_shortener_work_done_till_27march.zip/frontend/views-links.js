/* ─── views-links.js — Link table + Create/Update forms ──────── */

const EXPIRY_OPTIONS = [
  { value: 'never', label: 'Never expires' },
  { value: '1d',    label: '1 day' },
  { value: '7d',    label: '7 days' },
  { value: '30d',   label: '30 days' },
  { value: '90d',   label: '90 days' },
];

function renderLinksSection(project) {
  const section = document.getElementById('links-section');
  section.innerHTML = `
    <div class="section-header">
      <span class="section-title">Links</span>
      ${project.is_active ? `<button class="btn btn--primary btn--sm" id="new-link-btn">
          <svg class="icon"><use href="#ico-plus"/></svg> New Link
        </button>` : `<span class="badge badge--red">Project inactive — cannot add links</span>`}
    </div>
    ${project.is_active ? renderCreateLinkForm(project.id) : ''}
    <div id="links-table-wrap">
      <div class="empty-state"><div class="skeleton" style="height:160px;width:100%"></div></div>
    </div>`;

  if (project.is_active) {
    document.getElementById('new-link-btn').onclick = () => {
      const formWrap = document.getElementById('create-link-form-wrap');
      formWrap.style.display = formWrap.style.display === 'none' ? 'block' : 'none';
    };
  }
  loadLinksTable(project.id);
}

function renderCreateLinkForm(projectId) {
  return `
    <div id="create-link-form-wrap" class="card mb-24" style="display:none">
      <h3 style="font-size:15px;font-weight:700;margin-bottom:16px">Create Short Link</h3>
      <form id="create-link-form">
        <div class="form-group">
          <label>Destination URL</label>
          <input id="lf-url" type="url" placeholder="https://example.com/very/long/path" required/>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Custom Code <span style="font-weight:400;color:var(--text-muted)">(optional)</span></label>
            <input id="lf-code" type="text" placeholder="my-link" maxlength="20" pattern="[a-zA-Z0-9\\-]+"/>
            <span class="form-hint">4–20 chars, letters, numbers, hyphens only.</span>
          </div>
          <div class="form-group">
            <label>Expiry</label>
            <select id="lf-expiry">
              ${EXPIRY_OPTIONS.map(o=>`<option value="${o.value}">${o.label}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="form-group">
          <label>Title <span style="font-weight:400;color:var(--text-muted)">(optional)</span></label>
          <input id="lf-title" type="text" placeholder="Descriptive title" maxlength="255"/>
        </div>
        <div id="lf-err" class="form-error mb-16" style="display:none"></div>
        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button type="button" class="btn btn--ghost" onclick="document.getElementById('create-link-form-wrap').style.display='none'">Cancel</button>
          <button type="submit" class="btn btn--primary" id="lf-submit">Create Link</button>
        </div>
      </form>
    </div>`;
}

async function loadLinksTable(projectId, page = 1) {
  const wrap = document.getElementById('links-table-wrap');
  try {
    const data = await LinksAPI.list(projectId, page, 20);
    renderLinksTable(wrap, data, projectId, page);
  } catch(err) {
    wrap.innerHTML = `<div class="empty-state"><svg class="icon"><use href="#ico-alert"/></svg><h3>Failed to load links</h3><p>${err.message}</p></div>`;
  }        
  // Bind create form
  const form = document.getElementById('create-link-form');
  if (form) {
    form.onsubmit = async e => {
      e.preventDefault();
      const btn = document.getElementById('lf-submit');
      const errEl = document.getElementById('lf-err');
      errEl.style.display = 'none';
      btn.disabled = true; btn.textContent = 'Creating…';
      const custom = document.getElementById('lf-code').value.trim();
      const body = {
        original_url: document.getElementById('lf-url').value.trim(),
        expiry: document.getElementById('lf-expiry').value,
        title: document.getElementById('lf-title').value.trim() || null,
      };
      if (custom) body.custom_code = custom;
      try {
        await LinksAPI.create(projectId, body);
        Toast.success('Link created!');
        document.getElementById('create-link-form-wrap').style.display = 'none';
        form.reset();
        loadLinksTable(projectId);
      } catch(err) {
        errEl.textContent = err.message; errEl.style.display = 'block';
      } finally {
        btn.disabled = false; btn.textContent = 'Create Link';
      }
    };
  }
}

function renderLinksTable(container, data, projectId, page) {
  const { links, total, per_page } = data;
  if (!links.length) {
    container.innerHTML = `<div class="empty-state">
      <svg class="icon"><use href="#ico-link"/></svg>
      <h3>No links yet</h3>
      <p>Click "New Link" above to create your first short link.</p></div>`;
    return;
  }
  const totalPages = Math.ceil(total / per_page);
  container.innerHTML = `
    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>Short Code</th>
            <th>Destination</th>
            <th>Title</th>
            <th>Clicks</th>
            <th>Expires</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${links.map(l => linkRow(l, projectId)).join('')}
        </tbody>
      </table>
    </div>
    <div class="pagination">
      <span class="pagination-info">${total} total · Page ${page} / ${totalPages}</span>
      <div class="pagination-btns">
        <button class="btn btn--ghost btn--sm" ${page<=1?'disabled':''} onclick="loadLinksTable('${projectId}',${page-1})">
          <svg class="icon"><use href="#ico-chevron-left"/></svg> Prev
        </button>
        <button class="btn btn--ghost btn--sm" ${page>=totalPages?'disabled':''} onclick="loadLinksTable('${projectId}',${page+1})">
          Next <svg class="icon"><use href="#ico-chevron-right"/></svg>
        </button>
      </div>
    </div>`;
}

function linkRow(l, projectId) {
  const shortUrl = l.short_url;
  const expires  = l.expires_at ? new Date(l.expires_at).toLocaleDateString() : '—';
  const expired  = l.expires_at && new Date(l.expires_at) < new Date();
  return `<tr id="link-row-${l.id}">
    <td>
      <div class="short-code-cell">
        <span class="short-code">${escHtml(l.short_code)}</span>
        <button class="copy-btn" onclick="copyText('${shortUrl}',this)" title="Copy short URL">
          <svg class="icon"><use href="#ico-copy"/></svg>
        </button>
        <a href="${shortUrl}" target="_blank" title="Open">
          <svg class="icon" style="color:var(--text-muted)"><use href="#ico-external"/></svg>
        </a>
      </div>
    </td>
    <td><span class="link-url" title="${escHtml(l.original_url)}">${escHtml(l.original_url)}</span></td>
    <td style="color:var(--text-muted)">${l.title ? escHtml(l.title) : '—'}</td>
    <td><span class="badge badge--blue">${fmtNum(l.click_count)}</span></td>
    <td><span class="${expired?'badge badge--red':'text-muted'}">${expires}</span></td>
    <td>
      <span class="badge ${l.is_active?'badge--green':'badge--gray'}">
        ${l.is_active ? 'Active' : 'Inactive'}
      </span>
    </td>
    <td>
      <div class="table-actions">
        <button class="btn btn--ghost btn--icon btn--sm" title="Analytics"
          onclick="showLinkAnalytics('${projectId}','${l.id}')">
          <svg class="icon"><use href="#ico-bar-chart"/></svg>
        </button>
        <button class="btn btn--ghost btn--icon btn--sm" title="Edit title"
          onclick="showEditLinkModal('${projectId}','${l.id}','${escHtml(l.title||'')}')">
          <svg class="icon"><use href="#ico-edit"/></svg>
        </button>
        <button class="btn btn--ghost btn--icon btn--sm" title="${l.is_active?'Deactivate':'Activate'}"
          onclick="toggleLinkActive('${projectId}','${l.id}',${l.is_active})">
          <svg class="icon"><use href="${l.is_active?'#ico-toggle-on':'#ico-toggle-off'}"/></svg>
        </button>
        <button class="btn btn--ghost btn--icon btn--sm" title="Delete"
          onclick="confirmDeleteLink('${projectId}','${l.id}','${escHtml(l.short_code)}')">
          <svg class="icon" style="color:var(--danger)"><use href="#ico-trash"/></svg>
        </button>
      </div>
    </td>
  </tr>`;
}

async function toggleLinkActive(projectId, linkId, currentlyActive) {
  try {
    await LinksAPI.update(projectId, linkId, { is_active: !currentlyActive });
    Toast.success(currentlyActive ? 'Link deactivated.' : 'Link reactivated.');
    loadLinksTable(projectId);
  } catch(err) { Toast.error(err.message); }
}

function confirmDeleteLink(projectId, linkId, code) {
  Confirm.show(
    'Delete link?',
    `Short code /${code} will be permanently deleted. This cannot be undone.`,
    async () => {
      try {
        await LinksAPI.delete(projectId, linkId);
        Toast.success('Link deleted.');
        loadLinksTable(projectId);
      } catch(err) { Toast.error(err.message); }
    }
  );
}

function showEditLinkModal(projectId, linkId, currentTitle) {
  Modal.show('Edit Link', `
    <form id="edit-link-form">
      <div class="form-group" style="margin-bottom:20px">
        <label>Title</label>
        <input id="el-title" type="text" maxlength="255" placeholder="Descriptive title" value="${escHtml(currentTitle)}"/>
      </div>
      <div id="el-err" class="form-error mb-16" style="display:none"></div>
      <div style="display:flex;gap:10px;justify-content:flex-end">
        <button type="button" class="btn btn--ghost" onclick="Modal.hide()">Cancel</button>
        <button type="submit" class="btn btn--primary" id="el-submit">Save</button>
      </div>
    </form>`);

  document.getElementById('edit-link-form').onsubmit = async e => {
    e.preventDefault();
    const btn = document.getElementById('el-submit');
    const errEl = document.getElementById('el-err');
    errEl.style.display = 'none';
    btn.disabled = true; btn.textContent = 'Saving…';
    try {
      await LinksAPI.update(projectId, linkId, { title: document.getElementById('el-title').value.trim() || null });
      Modal.hide();
      Toast.success('Link updated.');
      loadLinksTable(projectId);
    } catch(err) {
      errEl.textContent = err.message; errEl.style.display = 'block';
    } finally {
      btn.disabled = false; btn.textContent = 'Save';
    }
  };
}
