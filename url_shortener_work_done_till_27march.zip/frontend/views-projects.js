/* ─── views-projects.js — Dashboard & Project Detail ─────────── */

const PROJECT_COLORS = ['#6366f1','#8b5cf6','#ec4899','#f59e0b','#10b981','#3b82f6','#ef4444','#06b6d4'];

// ── Dashboard ─────────────────────────────────────────────────
async function renderDashboard() {
  const view = document.getElementById('main-view');
  view.innerHTML = `
    <div class="page-header">
      <div>
        <h1 class="page-title">Dashboard</h1>
        <p class="page-subtitle">Manage your link projects</p>
      </div>
      <div class="page-actions">
        <button class="btn btn--primary" id="new-project-btn">
          <svg class="icon"><use href="#ico-plus"/></svg> New Project
        </button>
      </div>
    </div>
    <div id="projects-grid" class="card-grid">
      ${skeletonCards(6)}
    </div>`;

  document.getElementById('new-project-btn').onclick = () => showProjectModal();

  try {
    const data = await ProjectsAPI.list(1, 50);
    renderProjectCards(data.projects || []);
  } catch(err) {
    document.getElementById('projects-grid').innerHTML =
      `<div class="empty-state"><svg class="icon"><use href="#ico-alert"/></svg><h3>Failed to load projects</h3><p>${err.message}</p></div>`;
  }
}

function skeletonCards(n) {
  return Array.from({length:n}, () =>
    `<div class="card" style="height:160px">
       <div class="skeleton" style="height:16px;width:60%;margin-bottom:8px"></div>
       <div class="skeleton" style="height:12px;width:40%"></div>
     </div>`).join('');
}

function renderProjectCards(projects) {
  const grid = document.getElementById('projects-grid');
  if (!projects.length) {
    grid.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1">
        <svg class="icon"><use href="#ico-folder"/></svg>
        <h3>No projects yet</h3>
        <p>Create your first project to start shortening links.</p>
        <button class="btn btn--primary" onclick="showProjectModal()">
          <svg class="icon"><use href="#ico-plus"/></svg> New Project
        </button>
      </div>`;
    return;
  }
  grid.innerHTML = projects.map(p => `
    <div class="card project-card fade-in" style="--card-color:${p.color||'#6366f1'}"
         data-id="${p.id}" onclick="navigateTo('/projects/${p.id}')">
      <div class="project-card-header">
        <div>
          <div class="project-card-name">${escHtml(p.name)}</div>
          <div class="project-card-slug text-mono">${escHtml(p.slug)}</div>
        </div>
        <div class="card-actions" onclick="event.stopPropagation()">
          ${p.is_default ? '' : `
          <button class="btn btn--ghost btn--icon" title="Edit" onclick="showProjectModal('${p.id}')">
            <svg class="icon"><use href="#ico-edit"/></svg>
          </button>`}
          <button class="btn btn--ghost btn--icon" title="Analytics" onclick="showProjectAnalytics('${p.id}')">
            <svg class="icon"><use href="#ico-bar-chart"/></svg>
          </button>
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px">
        ${p.is_default ? '<span class="badge badge--purple">Default</span>' : ''}
        <span class="badge ${p.is_active ? 'badge--green' : 'badge--red'}">${p.is_active ? 'Active' : 'Inactive'}</span>
      </div>
      ${p.description ? `<p style="font-size:12.5px;color:var(--text-muted);margin-bottom:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(p.description)}</p>` : ''}
      <div class="project-card-meta">
        <div class="meta-stat">
          <span class="meta-stat-val">${p.link_count ?? 0}</span>
          <span class="meta-stat-lbl">Links</span>
        </div>
        <div class="meta-stat">
          <span class="meta-stat-val">${fmtNum(p.total_clicks ?? 0)}</span>
          <span class="meta-stat-lbl">Clicks</span>
        </div>
        <div class="meta-stat">
          <span class="meta-stat-val">${fmtNum(p.clicks_this_month ?? 0)}</span>
          <span class="meta-stat-lbl">This month</span>
        </div>
      </div>
    </div>`).join('');
}

// ── Project Modal (Create / Edit) ─────────────────────────────
async function showProjectModal(projectId = null) {
  let project = null;
  if (projectId) {
    try { project = await ProjectsAPI.get(projectId); } catch {}
  }
  const title = project ? 'Edit Project' : 'New Project';
  const selColor = project?.color || PROJECT_COLORS[0];
  Modal.show(title, `
    <form id="proj-form">
      <div class="form-group">
        <label>Project Name</label>
        <input id="pf-name" type="text" maxlength="100" placeholder="My Project" value="${escHtml(project?.name||'')}" required/>
      </div>
      <div class="form-group">
        <label>Description <span style="font-weight:400;text-transform:none;color:var(--text-muted)">(optional)</span></label>
        <textarea id="pf-desc" maxlength="500" placeholder="What's this project for?">${escHtml(project?.description||'')}</textarea>
      </div>
      <div class="form-group">
        <label>Color</label>
        <div class="color-row" id="color-row">
          ${PROJECT_COLORS.map(c => `
            <div class="color-swatch ${c===selColor?'selected':''}" style="background:${c}"
                 data-color="${c}" title="${c}" onclick="selectColor(this)"></div>`).join('')}
        </div>
        <input type="hidden" id="pf-color" value="${selColor}"/>
      </div>
      <div id="pf-err" class="form-error mb-16" style="display:none"></div>
      <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:20px">
        <button type="button" class="btn btn--ghost" onclick="Modal.hide()">Cancel</button>
        <button type="submit" class="btn btn--primary" id="pf-submit">${project ? 'Save Changes' : 'Create Project'}</button>
      </div>
    </form>`);

  document.getElementById('proj-form').addEventListener('submit', async e => {
    e.preventDefault();
    const btn = document.getElementById('pf-submit');
    const errEl = document.getElementById('pf-err');
    errEl.style.display = 'none';
    btn.disabled = true; btn.textContent = 'Saving…';
    const body = {
      name: document.getElementById('pf-name').value.trim(),
      description: document.getElementById('pf-desc').value.trim() || null,
      color: document.getElementById('pf-color').value,
    };
    try {
      if (project) await ProjectsAPI.update(project.id, body);
      else await ProjectsAPI.create(body);
      Modal.hide();
      Toast.success(project ? 'Project updated.' : 'Project created!');
      renderDashboard();
    } catch(err) {
      errEl.textContent = err.message; errEl.style.display = 'block';
    } finally {
      btn.disabled = false; btn.textContent = project ? 'Save Changes' : 'Create Project';
    }
  });
}

function selectColor(el) {
  document.querySelectorAll('#color-row .color-swatch').forEach(s => s.classList.remove('selected'));
  el.classList.add('selected');
  document.getElementById('pf-color').value = el.dataset.color;
}

// ── Project Detail ─────────────────────────────────────────────
async function renderProjectDetail(projectId) {
  const view = document.getElementById('main-view');
  view.innerHTML = `<div class="breadcrumb">
    <a href="#/dashboard">Dashboard</a>
    <svg class="icon"><use href="#ico-chevron-right"/></svg>
    <span id="proj-breadcrumb">Loading…</span>
  </div>
  <div class="page-header">
    <div>
      <h1 class="page-title" id="proj-title">…</h1>
      <p class="page-subtitle" id="proj-meta"></p>
    </div>
    <div class="page-actions">
      <button class="btn btn--ghost" id="proj-analytics-btn">
        <svg class="icon"><use href="#ico-bar-chart"/></svg> Analytics
      </button>
      <button class="btn btn--ghost" id="proj-edit-btn">
        <svg class="icon"><use href="#ico-edit"/></svg> Edit
      </button>
    </div>
  </div>
  <div id="links-section"></div>`;

  // Load project
  let project;
  try {
    project = await ProjectsAPI.get(projectId);
  } catch(err) {
    view.innerHTML = `<div class="empty-state">
      <svg class="icon"><use href="#ico-alert"/></svg>
      <h3>Project not found</h3><p>${err.message}</p>
      <a href="#/dashboard" class="btn btn--ghost">← Back</a></div>`;
    return;
  }

  document.getElementById('proj-breadcrumb').textContent = project.name;
  document.getElementById('proj-title').textContent = project.name;
  document.getElementById('proj-meta').innerHTML =
    `<span class="text-mono" style="color:var(--text-muted)">${project.slug}</span>
     &nbsp;·&nbsp; ${project.link_count} links &nbsp;·&nbsp; ${fmtNum(project.total_clicks)} total clicks`;
  document.getElementById('proj-analytics-btn').onclick = () => showProjectAnalytics(projectId);
  document.getElementById('proj-edit-btn').onclick = () => showProjectModal(projectId);

  renderLinksSection(project);
}

async function showProjectAnalytics(projectId) {
  Modal.show('Project Analytics', `<div class="empty-state"><div class="skeleton" style="height:200px;width:100%"></div></div>`);
  try {
    const a = await ProjectsAPI.analytics(projectId);
    Modal.setContent(`
      <h2 class="modal-title">Project Analytics</h2>
      <div class="stats-strip" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px">
        ${statBox(a.total_clicks,'Total Clicks')}
        ${statBox(a.clicks_this_month,'This Month')}
        ${statBox(a.total_links,'Total Links')}
      </div>
      <div class="chart-box">
        <div class="chart-title">30-Day Click Timeline</div>
        ${timelineChart(a.clicks_over_time||[], 'timeline-canvas-proj')}
      </div>`);
    renderTimelineChart('timeline-canvas-proj', a.clicks_over_time || []);
  } catch(err) {
    Modal.setContent(`<p class="form-error">${err.message}</p>`);
  }
}
